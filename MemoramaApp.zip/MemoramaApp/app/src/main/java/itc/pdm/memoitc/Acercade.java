package itc.pdm.memoitc;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Adan on 22/09/2015.
 */
public class Acercade extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acercade);
    }
}
